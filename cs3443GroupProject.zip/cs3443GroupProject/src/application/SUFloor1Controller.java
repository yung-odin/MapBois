package application;

import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.*;

import javafx.application.*;
import javafx.event.*;

public class SUFloor1Controller implements Initializable, EventHandler<ActionEvent>
{
	public int iCircSize = 7;
	   @Override
	    public void handle(ActionEvent actionEvent)
	    {
	    	
	    }
	    
	    @Override
	    public void initialize(URL url, ResourceBundle resourceBundle)
	    {
	    	
	    }
}
